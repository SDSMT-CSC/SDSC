//
//  RHDeviceModel.m
//  RemoteHome
//
//  Created by James Wiegand on 1/8/13.
//  Copyright (c) 2013 James Wiegand. All rights reserved.
//

#import "RHDeviceModel.h"

@implementation RHDeviceModel

@end
